die "I don't wanna\n";

1;
